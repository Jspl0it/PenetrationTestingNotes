# Content Discovery

Learn the various ways of discovering hidden or private content on a web-server that could lead to new vulnerabilities.