# Penetration Testing Frameworks

# **OSSTMM**

The **Open Source Security Testing Methodology Manual**

- Provides a detailed framework of testing strategies for systems, software,	applications, communications and the human aspects of cybersecurity.
    - [https://www.isecom.org/OSSTMM.3.pdf](https://www.isecom.org/OSSTMM.3.pdf)

The methodology focuses primarily on how these systems, applications communicate, so it
includes a methodology for:

1. **Telecommunications (phones, VoIP, etc.)**
2. Wired Networks
3. Wireless communications

| Advantages | Disadvantages |
| --- | --- |
| Covers various testing strategies in-depth | The Framework is difficult to understand, very detailed, and tends
to use unique definitions. |
| Includes testing strategies for specific targets (i.e.
telecommunications and networking) |  |
| The framework is flexible depending upon the organizations needs |  |
| The framework is meant to set a standard for systems and applications

Meaning that a universal methodology can be used
in a penetration testing scenario. |  |

# **OWASP**

The “****************************Open Web Application Security Project”**************************** framework is a community-driven and frequently updated framework used solely to test the security of web applications and services.

The foundation regularly writes reports stating the top ten security vulnerabilities a web application may have, the testing approach, and remediation.

| Advantages | Disadvantages |
| --- | --- |
| Easy to pick up and understand. | It may not be clear what type of vulnerability a web application has (they can often overlap). |
| Actively maintained and is frequently updated. | OWASP does not make suggestions to any specific software development life cycles. |
| It covers all stages of an engagement: from testing to reporting and remediation. | The framework doesn't hold any accreditation such as CHECK. |
| Specializes in web applications and services. | Intentionally left blank. |

# **NIST**

The NIST Cybersecurity Framework is a popular framework used to improve an organizations cybersecurity standards and manage the risk of cyber threats. This framework is a bit of an honorable mention because of its popularity and detail.

The framework provides guidelines on security controls & benchmarks for success for organizations from critical infrastructure to commercial. 

There is a limited section on a standard guideline for the methodology a penetration tester should take.

| Advantages | Disadvantages |
| --- | --- |
| The NIST Framework is estimated to be used by 50% of American organizations by 2020. | NIST has many iterations of frameworks, so it may be difficult to decide which one applies to your organization. |
| The framework is extremely detailed in setting standards to help organizations mitigate the threat posed by cyber threats. | The NIST framework has weak auditing policies, making it difficult to determine how a breach occurred. |
| The framework is very frequently updated. | The framework does not consider cloud computing, which is quickly becoming increasingly popular for organizations. |
| NIST provides accreditation for organizations that use this framework. | Intentionally left blank. |
| The NIST framework is designed to be implemented alongside other frameworks. | Intentionally left blank. |

# **NCSC CAF**

The [Cyber Assessment Framework](https://www.ncsc.gov.uk/collection/caf/caf-principles-and-guidance) (CAF) is an extensive framework of fourteen principles used to assess  the risk of various cyber threats and an organization's defenses against these.

The framework applies to organizations considered to perform "vitally 
important services and activities" such as critical infrastructure, banking, and the likes. The framework mainly focuses on and assesses the
 following topics:

- Data security
- System security
- Identity and access control
- Resiliency
- Monitoring
- Response and recovery planning