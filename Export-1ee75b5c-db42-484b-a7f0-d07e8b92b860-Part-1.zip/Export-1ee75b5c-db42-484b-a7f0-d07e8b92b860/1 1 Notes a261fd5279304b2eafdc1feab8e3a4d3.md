# 1:1 Notes

<aside>
💡 **Notion Tip:** Click the `Add a new 1:1`  button to create a new meeting toggle with today’s date.

</aside>

### March 20, 2023

### Max

- Priorities/Projects
- To Discuss
- Feedback to Lily

### Lily

- Priorities/Projects
- To Discuss
- Feedback to Max

### March 13, 2023

### Max

- Priorities/Projects
- To Discuss
- Feedback to Lily

### Lily

- Priorities/Projects
- To Discuss
- Feedback to Max

### March 6, 2023

### Max

- Priorities/Projects
- To Discuss
- Feedback to Lily

### Lily

- Priorities/Projects
- To Discuss
- Feedback to Max